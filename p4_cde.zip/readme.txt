This is multisession CD with FreeDOS boot OS. You should place 
'+4 forever?' emulator executable file (plus4.exe) to the root 
directory of any next track of this CD.

You may also add any desired +4 software (d64, prg, p00, tap, ctf, ...) 
to the next tracks of this disk.

Don't forget to place your favorite configuration file (plus4.cfg) to 
the root directory.
