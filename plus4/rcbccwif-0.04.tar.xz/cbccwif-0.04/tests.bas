10 rem rcbcwif test suite
15 rem the base arithmetic and integer type conversion
20 scnclr:print "pass";n%;", free memory";fre(0):n%=n%+1:print
25 a%=10:b%=-1000:c=a%+b%:d%=a%*b%:let f%=(c^1-b%)/-5:g=int(-b%*c)
30 print "bc:";a%;b%;c;d%;f%;g;f%^3
40 print "ok: 10 -1000 -990 -10000 -2 -990000 -8"
45 print
50 print "bc:";a%<b%;c<a%;b%=c-10;b%=f%;c>f%;f%>c;f%>=g;g=>f%;c<=g;c<=c;b%<>-10+c;b%<>f%
60 print "ok: 0 -1 -1  0  0 -1 -1  0  0 -1  0 -1"
65 print
70 print "bc:";abs(a%);abs(g);sgn(b%);sgn(c-a%-b%);sgn(f%^4);a%andb%;a%orb%;not c;(-c+1)and(a%-5)
80 print "ok: 10  990000 -1  0  1  8 -998  989  5"
85 print:print"quintuple digits"
90 for i=48 to 57:print chr$(i);chr$(asc(chr$(i)));dec(chr$(i));hex$(dec(chr$(i)));val(chr$(i)):next
95 print:getkeya$
100 print "bc: ";hex$(a%);chr$(a%+55);asc("q");val(str$(g-4*f%));val(str$(c*2));dec(str$(-c));str$(5^-f%);val(str$(a%/2))
110 print "ok: 000aa 81 -989992 -1980  2448  25 5"
115 print
120 print "bc: ";hex$(c*-60);dec("ff"+"01");val("7"+str$(1-g));val(chr$(asc("8"))+chr$(55));dec("5a")*val(chr$(c+51-c));chr$(peek(114000/100)-4)
130 print "ok: e808 65281  7990001  87  270 7"
135 x=1:print
140 print "bc: ";7tab(12)88,4;spc(7)8;43spc(x)4
150 print "ok:  7       88      4         8  43   4"
155 print
160 print "bc:";:pokedec("7f2"),64:sys65490:print,"ok: @"
170 print
180 print"bc: ";:printusing"#>####";a%,b%*b%,f%+d%/100,c,g/-10
190 print"ok:     10******  -102  -990 99000"
200 print
210 print"bc: ";:printusing"#####>#";"ok","hello","world",-b%
220 print"ok:      ok  hello  world   1000"
270 getkeya$:b%=1
280 for i=0 to 999:poke 3072+i,b%:next:getkeya$
290 do while i>0:i=i-1:poke 3072+i,c+b%-c+1:loop:getkeya$
300 do:poke3072+i,2+b%:i=i+1:loop until i=1000:getkeya$
310 do:i=i-1:poke3072+i,3+b%:ifi=0thenexit:loop:getkeya$
320 scnclr:a%=0:print "on goto"
340 on a% goto 350,360,370,380
350 a%=a%+1:print35;:ifa%<7goto340:else390
360 a%=a%+1:print36;:goto340
370 a%=a%+1:print37;:goto340
380 a%=a%+1:print38;:goto340
390 printa%;39
400 print35;35;36;37;38;35;35;7;39
405 a$=""
410 for i=0 to 1
420 for c=0 to 1
430 for g=0 to 1 step 1
440 for k=0 to 1
450 if i then a$=a$+"1":if c then a$=a$+"2":else a$=a$+"3":if g then a$=a$+"4":a$=a$+"5":else a$=a$+"6":if k then a$=a$+"7":else:a$=a$+"8":elsea$=a$+"9"
460 a$=a$+"*"
470 next k,g,c,i
475 print
480 if a$="368*367*345*345*368*367*345*345*1368*1367*1345*1345*12*12*12*12*" then print "if=ok"
490 print:print "for":a%=-10
500 for i=1000000 to 999990 step a%
510 print i;
520 next
530 print i
540 print 1000000;999990;999980
550 a%=0:print "on gosub"
560 on a% gosub 10010,10010,10020,10020,10030,10030,10040
565 printa%;:a%=a%+1
570 if a%<8 goto560
580 print:print " 0  5  2  6  4  7  6  8  8"
590 g=1:gosub10050:ifg=4thenprint"gosub ok":elseprint"wrong gosub"
600 i=0:g=0:gosub10080:print"the gosub recursion, level";i
610 ti$="235957":print"bc:";ti;ti$:print"ok: 5183820 235957"
620 poke165,0:poke164,0:print"4.3 sec delay":wait164,1
630 print"2.1 sec delay":wait165,128
635 z=ti
650 dima$(1000),b%(10,10,10),ar%(1400)
660 for i=0 to 1000:a$(i)=ti$:next
670 for i=0 to 10:for c=0 to 10:for k=0 to 10:b%(i,c,k)=i*110+c*11+k:nextk,c,i
680 g=0:for i=0 to 10:for c=0 to 10:for k=0 to 10:g=g+b%(i,c,k):nextk,c,i
690 print "bc:";g,"ok: 811910"
700 g=0:for i=0 to 10:for c=0 to 10:for k=0 to 10:ar%(g)=b%(i,c,k):g=g+1:nextk,c,i
710 for i=0 to 1000:a$(i)=str$(ar%(i)):next
720 g=0:for i=0 to 1000:g=g+(val(a$(i))and511):next
730 print "bc:";g,"ok: 232488":print"bc:";ti-z,"ok: 822-+1"
10000 end
10010 a%=a%+1:print5;:return
10020 a%=a%+1:print6;:return
10030 a%=a%+1:print7;:return
10040 a%=a%+1:print8;:return
10050 print "gosub is working":g=g+1:gosub10060:return
10060 print "the nested gosub":g=g+1:gosub10070:return
10070 print "the deeply nested gosub":g=g+1:return
10080 i=i+1:if i<30 then gosub10080
10090 return
