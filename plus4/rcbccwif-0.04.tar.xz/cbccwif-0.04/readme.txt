HOW TO COMPILE THE COMPILER

The requirements: bison, make, c++, lex or flex, the pcrecpp library.  Just type `make'.


HOW TO USE

Just run `cbccwif INPUT.bas >OUTPUT.asm'.  This produces OUTPUT.asm in the TMPX assempler format.  The files `gc.s', `gc2.s', `cbm35basic.mac', `cbm35basic.inc', and `plus4.mac' have to be at the same directory as `INPUT.asm' at the assemble stage.  The script `compile-bas-tmpx' provides the pattern example.

You can start your loaded compiled code with RUN or SYS4109.  To start program that keeps its variables use POKE154,0:SYS4128.

Supported operators: ^ / * + - ( ) = < > <= >= =< => <> ><

Supported keywords:
ABS AND ASC ATN CHAR CHR$ CLOSE CLR CMD COLLECT COLOR COPY DATA DEC DEF DIM DIRECTORY DO DS DS$ ELSE END EXIT EXP FN FOR FRE GET GET# GETKEY GO GOSUB GOTO HEADER HEX$ IF INPUT INPUT# INSTR INT JOY KEY LEFT$ LEN LET LOAD LOG LOCATE LOOP MONITOR MID$ NEW NEXT NOT ON OR OPEN PEEK PI POKE POS PRINT PRINT# PUDEF RCLR RDOT READ REM RENAME RESTORE RETURN RGR RIGHT$ RLUM RUN SAVE SCNCLR SCRATCH SGN SOUND SPC ST STEP STR$ SYS TAB THEN TI TI$ TO TRAP UNTIL USING USR VAL VERIFY VOL WAIT WHILE

Unsupported keywords:
BOX CIRCLE CONT COS DRAW EL ER ERR$ GRAPHIC GSHAPE PAINT RESUME RND SCALE SIN SSHAPE STOP TAN TROFF TRON

Keywords that cannot be supported:
AUTO BACKUP DELETE DLOAD DSAVE HELP LIST RENUMBER


The diffrence with the ROM Basic:

+ variable names may have any length;

- instead of the floating point type the pseudo-fp type is used that is actually 3-byte integers;

- DIM doesn't allow variables in the dimensions definition;

- DIRECTORY allows only units numbers less than 10;

- no multiple NEXT-statements are allowed for one FOR;

- the TRAP effect is not removed automatically after the 1st error catched;

- USR uses the pseudo-fp instead of the Commodore fp;

* keywords should be spelled fully, the shortcuts are not allowed;

@ this program is distributed under the GNU General Public License, Version 2, or, at your discretion, any later version. The GNU General Public License is available via the Web at <http://www.gnu.org/copyleft/gpl.html>. The GPL is designed to allow you to alter and redistribute the package, as long as you do not remove that freedom from others;

@ This is free, fast and dirty compiler designed to compile Notepad+4.  It is not a Visual Studio.


The generated code generally uses the next zero page locations: 3-6, $14, $15, $22-$25, $39, $3a, $3f-$42, $bc, $bd, $f1, $f2, $f5, $f6 (5,6 used only with SQR).

