HOW TO COMPILE THE COMPILER

The requirements: bison, make, c++, lex or flex, the pcrecpp library.  Just type `make'.


HOW TO USE

Just run `rcbccwif INPUT.bas >OUTPUT.asm`.  This produces OUTPUT.asm in the TMPX assempler format.  The files `gc.s`, `gc2.s`, `cbm35basic.mac`, `cbm35basic.inc`, and `plus4.mac` must be at the same directory as `INPUT.asm` at the assemble stage.  The script `compile-bas-tmpx` provides the pattern example.  It is possible to use the `-no` option when invoking the compiler.  This option disables the optimization stage.  This stage has not been thoroughly tested.  If your code is not working the way you expect, try using this option.  There is a very small chance that this will help.

You can start your loaded compiled code with RUN or SYS4109.  To start program that keeps its variables use POKE154,0:SYS4128.

Supported operators: ^ / * + - ( ) = < > <= >= =< => <> ><

Supported keywords:
ABS AND ASC ATN CHAR CHR$ CLOSE CLR CMD COLLECT COLOR COPY DATA DEC DEF DIM DIRECTORY DO DS DS$ ELSE END ER ERR$ EXIT EXP FN FOR FRE GET GET# GETKEY GO GOSUB GOTO HEADER HEX$ IF INPUT INPUT# INSTR INT JOY KEY LEFT$ LEN LET LOAD LOG LOOP MONITOR MID$ NEW NEXT NOT ON OR OPEN PEEK PI POKE POS PRINT PRINT# PUDEF RCLR RDOT READ REM RENAME RESTORE RESUME RETURN RGR RIGHT$ RLUM RUN SAVE SCNCLR SCRATCH SGN SOUND SPC ST STEP STR$ SYS TAB THEN TI TI$ TO TRAP UNTIL USING USR VAL VERIFY VOL WAIT WHILE

Unsupported keywords:
BOX CIRCLE CONT COS DRAW EL GRAPHIC LOCATE GSHAPE PAINT RND SCALE SIN SSHAPE STOP TAN TROFF TRON

Keywords that cannot be supported:
AUTO BACKUP DELETE DLOAD DSAVE HELP LIST RENUMBER


The difference with ROM Basic:

- instead of the floating point type the pseudo-fp type is used that is actually 3-byte integers;

- CLR and RUN don't destroy variables, they just make them empty or zero;

- CMD only supports one parameter;

- DIM doesn't allow variables in the dimensions definition;

- DIRECTORY allows only unit numbers less than 10;

- ER has a very limited set of values (3, 14, 15, 16, 20);

- FOR-NEXT and DO-LOOP must be paired, i.e. one NEXT for one FOR;

- NEW does reset;

- RESUME only works in form RESUME LINE-NUMBER;

- RDOT always returns 0;

- USR uses the pseudo-fp instead of the Commodore fp, it places its argument to $61-$63 and returns the result from the same memory locations;

- keywords should be spelled fully, the shortcuts (but ?) are not allowed;

- this program is distributed under the GNU General Public License, Version 2, or, at your discretion, any later version. The GNU General Public License is available via the Web at <http://www.gnu.org/copyleft/gpl.html>. The GPL is designed to allow you to alter and redistribute the package, as long as you do not remove that freedom from others;

This is free, fast and dirty compiler initially designed only to compile Notepad+4.

The generated code generally uses the next zero page locations: 3-6, $14, $15, $22-$25, $39, $3a, $3f-$42, $bc, $bd, $f1, $f2, $f5, $f6 (5,6 used only with SQR).

The compiler uses RAM from $1001 to strdmax+$ff.  The `strdmax` variable is set in `cbm35basic.mac`.  It may be changed.  If a program doesn't use the heap (dynamic memory) then memory from `strsdyn` is not used by the compiler.  The value of the variable `strsdyn` can be found in the listing file.  BTW the listing file contains the list of all variables and functions at its end.

