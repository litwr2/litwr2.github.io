gc        lda #>strdmax       ;r2 - free
          cmp strdcurre+1
          ;bcc gc0   ;impossible branch
          bne exit3

          ;lda #<strdmax
          ;cmp strdcurre
          ;bcs exit3

gc0       .block
          ;lda strdstart+1
          lda #>strsdyn
          sta r3h
          ;lda strdstart
          lda #<strsdyn
          sta r3l
          lda r5l
          sta strestatic-2
          lda r5h
          sta strestatic-1    ;r5 is free now
ll7       lda #>strsstatic
          sta r1h
          lda #<strsstatic
          sta r1l
          lda #0
          sta r0h
          ;sta r0l
ll3       lda #>strestatic
          cmp r1h
          bne no8

          lda #<strestatic
          cmp r1l
          beq ll8

no8       ldy #0
          lda (r1l),y
          sta r4l
          iny
          lda (r1l),y
          sta r4h
          dey
          cmp r3h
          bne ll1

          lda r4l
          cmp r3l
          bne ll1

          lda (r4l),y
          sec
          adc r3l
          sta r3l
          bcc *+4
          inc r3h

ll4       lda #2
          clc
          adc r1l
          sta r1l
          bcc ll3

          inc r1h
          bcs ll3

ll8       lda r0h
          ;ora r0l
          beq ll2

          ldy #0
          lda (r0l),y
          sta r4l
          iny
          lda (r0l),y
          sta r4h
          lda r3h
          sta (r0l),y
          dey
          lda r3l
          sta (r0l),y

          ;ldy #0
          lda (r4l),y
          sta (r3l),y
          beq ll7

          sta r0h
          tax
ll6       iny
          lda (r4l),y
          sta (r3l),y
          dex
          bne ll6

          sec
          lda r0h
          adc r3l
          sta r3l
          bcc ll7

          inc r3h
          bne ll7   ;=jmp

ll1       bcc ll4

          lda r0h
          ;ora r0l
          bne ll5

lx1       lda r1l
          sta r0l
          lda r1h
          sta r0h
          bne ll4   ;=jmp

ll5       ldy #1
          lda (r0l),y
          cmp r4h
          bcc ll4
          bne lx1

          dey
          lda (r0l),y
          cmp r4l
          bcc ll4
          bcs lx1

ll2       lda r3l
          sta strdcurre
          lda r3h
          sta strdcurre+1
          ldx strestatic-2
          stx r5l
          ldx strestatic-1
          stx r5h
          ;lda strdcurre+1
          cmp #>strdmax
          beq gc_err
          .bend

exitgc    rts

gc_err    lda #16  ;out of memory
          jmp traphandle2   ;directly to OUT OF MEMORY ERROR??

