/* it converts PRG to Pnn in any Linux/Unix/DOS/Windows environments,
   it supports long filenames
  (C) VIII-2005, VII-2014 V. Lidovski under GNU GPL v2

compilation with GNU DJ DELORIE GCC (http://www.delorie.com/djgpp) 
under DOS/Windows:
  gcc -o prg2p00.exe prg2p00.c

with GNU GCC under Linux:
  gcc -o prg2p00 prg2p00.c

but almost any C compiler can be used
*/

#include <stdio.h>
#include <string.h>

FILE *fi, *fo;
char buf[63*1024] = "C64File", fni[256], fno[256], cbm_fn[17],
      fc[25], rmode[3] = "r", wmode[3] = "w";

unsigned char ascii2petcii[128] = {
//untran: 5c - \, 60 - `, 7b -{, 7d - }, 7e - ~
// 0   1   2   3   4   5   6   7   8   9   A   B   C   D   E   F
   0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 13,  0,  0,  0,  0,  0,  //0
   0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  //10
  32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,  //20
  48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63,  //30
  64, 97, 98, 99,100,101,102,103,104,105,106,107,108,109,110,111,  //40
 112,113,114,115,116,117,118,119,120,121,122, 91,191, 93, 94,164,  //50
 188, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,  //60
  80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90,179,125,171,163,  0   //70
};

int dosnames () {
    if (fi = fopen("a, 56[]=+","w")) {
        fclose(fi);
        remove("a, 56[]=+");
        return 0;
    }
    return 1;
}

int linuxfs () {
    int st = 1;
    fi = fopen(".\\754xyz@).$(","w");
    fclose(fi);
    if (fi = fopen("754xyz@).$(","r")) {
        fclose(fi);
        st = 0;
    }
    remove(".\\754xyz@).$(");
    return st;
}

int main(int argc, char *argv[]) {
  int i, dos, nix, upper = 0, dosfn = 0, type;

  if (argc == 3) {
    dosfn = (argv[2][0] == '2' || argv[2][1] == '2');
    upper = (argv[2][0] == 'u' || argv[2][1] == 'u' 
               || argv[2][0] == 'U' || argv[2][1] == 'U');
  }
  else if (argc == 4) {
    dosfn = (argv[2][0] == '2' || argv[3][0] == '2');
    upper = (argv[2][0] == 'u' || argv[3][0] == 'u' 
               || argv[2][0] == 'U' || argv[3][0] == 'U');
  }
  dosfn |= dos = dosnames();
  nix = linuxfs();

  printf("PRG/SEQ/USR to Pnn/Snn/Unn file converter v1.1\n");
  printf("by V.Lidovski, I-2006, VII-2014. This software is under GNU GPL v2.\n");
  printf("Filenames status: ");
  if (nix)
    printf("Linux or something like it\n");
  else if (dos)
    printf("DOS or CP/M\n");
  else
    printf("Microsoft Windows\n");

  if (argc < 2 || argc > 4 || argc > 2 && !upper && !dosfn) {
    printf("USAGE: prg2p00 rawCBMfile [mode] [uppercase]\n");
    printf("  mode=0 (default) creates Pnn/Snn/Unn file\n");
    printf("  mode=2 creates Pnn/Snn/Unn file with 8.3 DOS filename\n");
    printf("  uppercase=u converts filename letters to CBM uppercase\n"); 
    return 1;
  }

  strcpy(fni, argv[1]);
  i = strlen(fni) - 4;
  type = fni[i + 1];
  if (strcasecmp(".prg", fni + i) && strcasecmp(".seq", fni + i) && strcasecmp(".usr", fni + i)) {
    printf("Argument must be a PRG/SEQ/USR file!\n");
    return 2;
  }
  else {
    strncpy(fno, fni, strlen(fni) - 3);
    fno[i] = 0;
    if (strlen(fno) > 8 && dosfn) {
      fno[7] = fno[strlen(fno) - 1];
      fno[8] = 0;
    }
    strcat(fno, ".p00");
    fno[strlen(fno) - 3] = type;
    for (i = 0; i < 10; i++)
      if (fi = fopen(fno, "r")) {
        fclose(fi);
        fno[strlen(fno) - 1]++;
      }
      else
        break;
  }

  i = 0;
  while (i < strlen(fni) - 4 && i < 16) {
      if (!(cbm_fn[i] = ascii2petcii[fni[i]]))
          cbm_fn[i] = ' ';
      if (upper && fni[i] >= 'A' && fni[i] <= 'Z')
          cbm_fn[i] -= 32;
      i++;
  }
  while (i < 17)
    cbm_fn[i++] = 0;

  strcpy(buf + 8, cbm_fn);
  buf[25] = 0;

  if (nix) {
    strcpy(fc,"/");
    if (dosfn)
      strcat(fc," \"+*,.<=>:;?[\\]|");
  }
  else {
    strcat(rmode,"b");
    strcat(wmode,"b");
    strcpy(fc,"*/<>:?\\|");
    if (dosfn)
      strcat(fc," \"+,.=;[]");
  }

  i = 0;
  while (i < strlen(fno) - 4) {
    if (strchr(fc, fno[i]) != 0)
      fno[i] = '_';
    i++;
  }

  fi = fopen(fni, rmode);
  fo = fopen(fno, wmode);
  i = fread(buf + 26, 1, 63*1024 - 26, fi);
  fwrite(buf, 1, i + 26, fo);
  fclose(fo);
  fclose(fi);

  return 0;
}
