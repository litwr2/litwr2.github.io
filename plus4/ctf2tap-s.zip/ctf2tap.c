/*
CTF to C16 TAP v1 or v2 PAL converter
(C) I-2006, II-2007, VII-2012 V. Lidovski under GNU GPL v2
compilation (using DJ DELORIE GCC):
  gcc -o ctf2tap.exe ctf2tap.c
but almost any C compiler can be used
*/

#include<stdio.h>
#include<stdlib.h>

typedef unsigned uint32; /* should be unsigned long for 16 bits OS */

#define IBUF 2048
#define OBUF 32768

int conv(unsigned char *ibuf, unsigned char *obuf, long ilen, int period,
                int *phase, int *phaselen, int tapver, long *diffsum) {
  long i;
  unsigned int j, p = 0, t, t1, opl;

  for (i = 0; i < ilen; i++) {
    for (j = 0; j < 8; j++) {
      ++(*phaselen);
      if (!!(ibuf[i]&(1<<(7 - j))) != *phase) {
        *phase = !(*phase);
        if (tapver == 2) {
          t = *phaselen*1.04*period/8 + .5;
          if (t > 255) {
            t *= 8;
            t1 = t&65535;
            t = t >> 16;
            obuf[p++] = 0;
            obuf[p++] = t1%256;
            obuf[p++] = t1/256;
          }
          obuf[p++] = t;
        }
        else if (*phase) {
          opl = *phaselen;
          t = *phaselen*1.01*period/4 + .5;
          if (t > 255) {
            t *= 8;
            t1 = t&65535;
            t = t >> 16;
            obuf[p++] = 0;
            obuf[p++] = t1%256;
            obuf[p++] = t1/256;
          }
          obuf[p++] = t;
        }
        else
          *diffsum += !!((*phaselen - opl)/4);
        *phaselen = 0;
      }
    }
  }
  return p;
}

main(int argc, char *argv[]) {
  FILE *fi, *fo;
  unsigned char ibuf[IBUF], obuf[OBUF];
  int i, phase = 0, phaselen = 0;
  long l, ilen, olen, diffsum = 0;
  struct {
    short ver;
    short hpos;
    short cap;
  } CTFh;
  struct {
    uint32 endp;
    unsigned char tconst;
  } block_h;
  struct {
    char TAP[12];
    char ver;
    char machine;
    char video;
    char reserved;
    uint32 size;
  } TAPh = {
    'C', '1', '6', '-', 'T', 'A', 'P', 'E', '-', 'R', 'A', 'W',
    1, 2, 0, 0, 0};
  printf("CTF to TAP (PAL) converter v1.03 by V. Lidovski, VII-2012\n");
  printf("This program is distributed under GNU GPL\n");

  if (argc != 3 && (argc != 4 || argv[3][0] != '1' && argv[3][0] != '2')) {
    printf("USAGE: ctf2tap <CTFfile> <TAPfile> [<TAPversion>]\n");
    printf("   (default TAP version is 1)\n");
    printf("e.g.\n   tap2ctf tape1.ctf tape1.tap 2\n");
    printf("   tap2ctf data.ctf data.tap\n");
    exit(1);
  }
  if (argc == 4)
    TAPh.ver += argv[3][0] - '1';

  if ((fi = fopen(argv[1],"rb")) == 0) {
    fprintf(stderr, "It's impossible to open %s to read\n", argv[1]);
    exit(2);
  }
  if ((fo = fopen(argv[2],"wb")) == 0) {
    fprintf(stderr, "It's impossible to open %s to write\n", argv[2]);
    exit(3);
  }

  fread(&CTFh, 1, 6, fi);    /* reads CTF header */
  if (CTFh.cap == 1) {
    fprintf(stderr, "%s is empty\n", argv[1]);
    exit(4);
  }
  fwrite(&TAPh, 1, 20, fo);  /* saves empty TAP header */
  for (i = 1; i < CTFh.cap; i++) {
    fread(&block_h, 1, 5, fi);
    l = block_h.endp - ftell(fi); /* length of block */
    while (l > 0) {
      ilen = (l >= IBUF) ? IBUF : l;
      fread(ibuf, 1, ilen, fi);
      l -= ilen;
      olen = conv(ibuf, obuf, ilen, block_h.tconst, &phase, &phaselen,
        TAPh.ver, &diffsum);
      fwrite(obuf, 1, olen, fo);
    }
    if (i + 1 < CTFh.cap) {
      olen = 0;
      obuf[olen++] = 0;
      obuf[olen++] = 0;
      obuf[olen++] = 128;
      obuf[olen++] = 1;
      obuf[olen++] = 0;
      obuf[olen++] = 0;
      obuf[olen++] = 128;
      obuf[olen++] = 1; /* 0x30000 TED ticks = 0.2 sec */
      fwrite(obuf, 1, olen, fo);
    }
  }

  TAPh.size = ftell(fo) - 20;
  fseek(fo, 0, SEEK_SET);
  fwrite(&TAPh, 1, 20, fo); /* saves TAP header */

  fclose(fo);
  fclose(fi);

  if (diffsum > 200)
    printf ("Usage of TAP version 2 is recommended\n");
}
