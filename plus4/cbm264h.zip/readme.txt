   The creation of the boot disk from the image file

Type RAWRITE and answer the questions in the DOS/Windows environment.

Type
     dd if=cbm264g.img of=/dev/fd0
in the Linux/Unix environment.

The diskette must be formatted!
