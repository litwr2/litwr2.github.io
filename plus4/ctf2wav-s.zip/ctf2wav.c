/*
CTF to WAV 8-bit mono 44100Hz converter v1.03
(C) VIII-2003, VII,VIII-2012 V. Lidovski under GNU GPL v2
compilation (using DJ DELORIE GCC):
  gcc -o ctf2wav.exe ctf2wav.c
but almost any C compiler can be used
*/

#include<stdio.h>
#include<stdlib.h>

typedef unsigned uint32;
/* typedef unsigned long uint32; */ /* for 16 bits OS */

#define IBUF 128
#define OBUF 32768
#define PALFREQ 886723
#define WAVFREQ 44100

int conv(unsigned char *ibuf, unsigned char *obuf, long ilen, int period, int inv, int sl) {
   long i;
   int j, p = 0, k, t;

   for (i = 0; i < ilen; i++) {
      for (j = 0; j < 8; j++) {
         t = 128 + ((!(ibuf[i]&(1 << (7 - j))) == !inv)? -sl: +sl);
         for (k = 0; k < period; k++)
            obuf[p + j*period + k] = t;
      }
      p += 8*period;
   }
   return p;
}

void makegap(unsigned char * buf, long len) {
   while (len--)
      buf[len] = 128;
}

main(int argc, char *argv[]) {
   FILE *fi, *fo;
   unsigned char ibuf[IBUF], obuf[OBUF];
   int i, period, p = 0, ifi = 0, ifo = 0, sl = 96;
   long l, ilen, olen;
   struct {
      short ver;
      short hpos;
      short cap;
   } CTFh;
   struct {
      uint32 endp;
      unsigned char tconst;
   } block_h;
   struct {
      char RIFF[4];
      uint32 osize;
      char FORMAT[8];
      uint32 fmtlen;
      short fdd;
      short noc;
      uint32 freq;
      uint32 abps;
      short bs;
      short bpv;
      char DATA[4];
      uint32 soundlen;
   } WAVh = {
      'R', 'I', 'F', 'F',
      0,
      'W', 'A', 'V', 'E', 'f', 'm', 't', ' ',
      16, 1, 1, WAVFREQ, WAVFREQ, 1, 8,
      'd', 'a', 't', 'a',
      0};

   if (argc < 2 || argc > 6) {
message:
      fprintf(stderr, "USAGE: ctf2wav [-i] [-s <number>] <CTFfile> <WAVfile>\n");
      fprintf(stderr, "       ctf2wav -V\n");
      fprintf(stderr, "       ctf2wav [-h]\n");
      fprintf(stderr, "Use -i to invert signal, a number after -s sets the signal level\n");
      fprintf(stderr, "This number should be in range 4..127 (default 96)\n");
      fprintf(stderr, "The option -V prints version information, the option -h displays this help\n");
      exit(1);
   }
   for (i = 1; i < argc; i++) {
      if (argv[i][0] == '-' && argv[i][2] == 0)
         switch (argv[i][1]) {
         case 'i': 
            p = 1;
            break;
         case 'h':
            goto message;
         case 'V':
            if (i != 1)
               goto message;
            printf("CTF to WAV converter v1.03 by V. Lidovski, VIII-2012\n");
            printf("This program is distributed under GNU GPL\n");
            return;
         case 's':
            if (i + 1 < argc)
               sl = atoi(argv[++i]);
            else {
               fprintf(stderr, "The signal level value is omitted\n");
               exit(7);
            }
            if (sl > 127 || sl < 4) {
               fprintf(stderr, "The signal level value is wrong\n");
               exit(6);
            }
            break;
         default:
            fprintf(stderr, "Wrong option\n");
            exit(8);
         }
      else if (ifi == 0) ifi = i;
      else if (ifo == 0) ifo = i;
      else {
         fprintf(stderr, "Wrong parameters\n");
         exit(5);
      }
   }
   if (ifi == 0) {
      fprintf(stderr, "Input filename is missed\n");
      exit(9);
   }
   if (ifo == 0) {
      fprintf(stderr, "Output filename is missed\n");
      exit(10);
   }
   if ((fi = fopen(argv[ifi], "rb")) == 0) {
      fprintf(stderr, "It's impossible to open %s to read\n", argv[ifi]);
      exit(2);
   }
   if ((fo = fopen(argv[ifo], "wb")) == 0) {
      fprintf(stderr, "It's impossible to open %s to write\n", argv[ifo]);
      exit(3);
   }

   fread(&CTFh, 1, 6, fi);   /* reads CTF header */

   if (CTFh.cap == 1) {
      fprintf(stderr, "%s is empty\n", argv[ifi]);
      exit(4);
   }

   fwrite(obuf, 1, 44, fo);  /* saves empty WAV header */

   for (i = 1; i < CTFh.cap; i++) {
      fread(&block_h, 1, 5, fi);
      period = (double) WAVFREQ*block_h.tconst/PALFREQ + 0.5;
      l = block_h.endp - ftell(fi); /* length of block */
      while (l > 0) {
         ilen = (l >= IBUF) ? IBUF : l;
         fread(ibuf, 1, ilen, fi);
         l -= ilen;
         olen = conv(ibuf, obuf, ilen, period, p, sl);
         fwrite(obuf, 1, olen, fo);
      }
      if (i + 1 < CTFh.cap) {
         makegap(obuf, 4096);
         fwrite(obuf, 1, 4096, fo);
      }
   }

   WAVh.osize = ftell(fo) - 8;
   WAVh.soundlen = ftell(fo) - 44;
   fseek(fo, 0, SEEK_SET);
   fwrite(&WAVh, 1, 44, fo); /* saves WAV header */

   fclose(fo);
   fclose(fi);
}

